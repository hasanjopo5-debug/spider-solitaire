import { useGame } from './hooks/useGame';
import { Column } from './components/Column';
import { Stock } from './components/Stock';
import { CompletedPile } from './components/CompletedPile';
import { DifficultySelector } from './components/DifficultySelector';
import { GameStats } from './components/GameStats';
import { WinModal } from './components/WinModal';
import { Difficulty } from './types/game';
import { sounds } from './utils/sounds';

export function App() {
  const {
    tableau,
    completed,
    moves,
    time,
    difficulty,
    selectedCard,
    gameStarted,
    gameWon,
    animatingCards,
    soundEnabled,
    canDeal,
    remainingDeals,
    startNewGame,
    handleCardClick,
    handleEmptyColumnClick,
    handleDeal,
    setSelectedCard,
    toggleSound,
  } = useGame();

  const handleStartGame = (d: Difficulty) => {
    sounds.init();
    startNewGame(d);
  };

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-900 via-green-800 to-green-900 flex items-center justify-center p-4">
        <div className="text-center">
          <div className="mb-8">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-2 drop-shadow-lg">
              🕷️ Spider Solitaire
            </h1>
            <p className="text-green-200 text-lg">Select difficulty to start</p>
          </div>
          
          <div className="mb-8">
            <DifficultySelector
              currentDifficulty={difficulty}
              onSelect={handleStartGame}
            />
          </div>
          
          <div className="bg-green-950/50 rounded-xl p-6 max-w-md mx-auto text-left text-green-200">
            <h3 className="font-bold text-white mb-3">How to Play:</h3>
            <ul className="space-y-2 text-sm">
              <li>• Build descending sequences from King to Ace</li>
              <li>• Complete sequences of the same suit are removed</li>
              <li>• Move cards that form a sequence of the same suit</li>
              <li>• Click on the deck to deal new cards (all columns must have cards)</li>
              <li>• Complete all 8 sequences to win!</li>
            </ul>
          </div>
          
          <div className="mt-6 text-green-300 text-sm">
            🔊 Sound effects enabled
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen bg-gradient-to-br from-green-900 via-green-800 to-green-900 p-2 md:p-4"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          setSelectedCard(null);
        }
      }}
    >
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-4 px-2">
        <div className="flex items-center gap-4">
          <h1 className="text-xl md:text-2xl font-bold text-white">
            🕷️ Spider Solitaire
          </h1>
          <GameStats moves={moves} time={time} />
        </div>
        
        <div className="flex gap-2">
          {/* Sound Toggle Button */}
          <button
            onClick={toggleSound}
            className="px-3 py-2 bg-green-800/50 hover:bg-green-700/50 text-green-200 rounded-lg font-medium transition-all duration-200"
            title={soundEnabled ? 'Mute sounds' : 'Unmute sounds'}
          >
            {soundEnabled ? '🔊' : '🔇'}
          </button>
          <button
            onClick={() => startNewGame()}
            className="px-4 py-2 bg-green-700 hover:bg-green-600 text-white rounded-lg font-medium shadow-md hover:shadow-lg transition-all duration-200"
          >
            New Game
          </button>
          <button
            onClick={() => startNewGame(difficulty)}
            className="px-4 py-2 bg-green-800/50 hover:bg-green-700/50 text-green-200 rounded-lg font-medium transition-all duration-200"
          >
            Restart
          </button>
        </div>
      </div>

      {/* Difficulty indicator */}
      <div className="flex justify-center mb-4">
        <div className="inline-flex gap-2 bg-green-950/50 rounded-lg p-1">
          {([1, 2, 4] as Difficulty[]).map((d) => (
            <button
              key={d}
              onClick={() => startNewGame(d)}
              className={`px-3 py-1 rounded text-sm font-medium transition-all duration-200 ${
                d === difficulty
                  ? 'bg-green-600 text-white'
                  : 'text-green-300 hover:bg-green-800/50'
              }`}
            >
              {d === 1 ? '1 Suit' : d === 2 ? '2 Suits' : '4 Suits'}
            </button>
          ))}
        </div>
      </div>

      {/* Game Area */}
      <div className="flex flex-col items-center">
        {/* Tableau */}
        <div className="flex gap-1 md:gap-2 mb-6 overflow-x-auto pb-4 max-w-full">
          {tableau.map((column, columnIndex) => (
            <Column
              key={columnIndex}
              cards={column}
              columnIndex={columnIndex}
              selectedCard={selectedCard}
              onCardClick={handleCardClick}
              onColumnClick={() => handleEmptyColumnClick(columnIndex)}
              animatingCards={animatingCards}
            />
          ))}
        </div>

        {/* Bottom Area - Stock and Completed */}
        <div className="flex items-center justify-between w-full max-w-4xl px-4">
          <Stock
            remainingDeals={remainingDeals}
            canDeal={canDeal}
            onDeal={handleDeal}
          />
          
          {!canDeal && remainingDeals > 0 && (
            <div className="text-center text-yellow-300 text-sm bg-yellow-900/30 px-4 py-2 rounded-lg">
              ⚠️ Fill all empty columns before dealing
            </div>
          )}
          
          <CompletedPile count={completed} />
        </div>
      </div>

      {/* Win Modal */}
      {gameWon && (
        <WinModal
          moves={moves}
          time={time}
          difficulty={difficulty}
          onNewGame={() => startNewGame()}
        />
      )}
    </div>
  );
}
