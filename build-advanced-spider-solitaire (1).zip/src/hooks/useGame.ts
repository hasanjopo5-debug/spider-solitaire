import { useState, useCallback, useEffect } from 'react';
import { Card, Difficulty } from '../types/game';
import {
  initializeGame,
  canMoveCards,
  canPlaceCards,
  checkForCompleteRun,
  flipTopCard,
  canDealFromStock,
  dealFromStock,
  getMovableCardCount,
  isGameWon,
} from '../utils/gameLogic';
import { sounds } from '../utils/sounds';

export interface Selection {
  columnIndex: number;
  cardIndex: number;
}

export function useGame(initialDifficulty: Difficulty = 1) {
  const [difficulty, setDifficulty] = useState<Difficulty>(initialDifficulty);
  const [tableau, setTableau] = useState<Card[][]>([]);
  const [stock, setStock] = useState<Card[]>([]);
  const [completed, setCompleted] = useState(0);
  const [moves, setMoves] = useState(0);
  const [selectedCard, setSelectedCard] = useState<Selection | null>(null);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameWon, setGameWon] = useState(false);
  const [time, setTime] = useState(0);
  const [animatingCards, setAnimatingCards] = useState<Set<string>>(new Set());
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Initialize audio context on first user interaction
  useEffect(() => {
    const initAudio = () => {
      sounds.init();
      window.removeEventListener('click', initAudio);
      window.removeEventListener('touchstart', initAudio);
    };
    
    window.addEventListener('click', initAudio);
    window.addEventListener('touchstart', initAudio);
    
    return () => {
      window.removeEventListener('click', initAudio);
      window.removeEventListener('touchstart', initAudio);
    };
  }, []);

  // Sync sound mute state
  useEffect(() => {
    sounds.setMuted(!soundEnabled);
  }, [soundEnabled]);

  // Initialize new game
  const startNewGame = useCallback((newDifficulty?: Difficulty) => {
    const diff = newDifficulty ?? difficulty;
    setDifficulty(diff);
    const { tableau: newTableau, stock: newStock } = initializeGame(diff);
    setTableau(newTableau);
    setStock(newStock);
    setCompleted(0);
    setMoves(0);
    setSelectedCard(null);
    setGameStarted(true);
    setGameWon(false);
    setTime(0);
    sounds.newGame();
  }, [difficulty]);

  // Timer
  useEffect(() => {
    if (!gameStarted || gameWon) return;
    
    const timer = setInterval(() => {
      setTime(t => t + 1);
    }, 1000);
    
    return () => clearInterval(timer);
  }, [gameStarted, gameWon]);

  // Check for completed runs
  const checkAndRemoveRuns = useCallback((newTableau: Card[][]): Card[][] => {
    let updated = [...newTableau];
    let foundRun = true;
    
    while (foundRun) {
      foundRun = false;
      
      for (let colIdx = 0; colIdx < updated.length; colIdx++) {
        const column = updated[colIdx];
        const { hasRun, runStartIndex } = checkForCompleteRun(column);
        
        if (hasRun) {
          foundRun = true;
          
          // Animate the cards being removed
          const cardsToRemove = column.slice(runStartIndex, runStartIndex + 13);
          setAnimatingCards(new Set(cardsToRemove.map(c => c.id)));
          
          // Play complete run sound
          sounds.completeRun();
          
          // Remove the run
          const newColumn = [
            ...column.slice(0, runStartIndex),
            ...column.slice(runStartIndex + 13),
          ];
          
          // Flip the new top card if needed
          const flippedColumn = flipTopCard(newColumn);
          
          // Play flip sound if a card was flipped
          if (flippedColumn.length > 0 && 
              newColumn.length > 0 && 
              !newColumn[newColumn.length - 1].faceUp) {
            setTimeout(() => sounds.cardFlip(), 300);
          }
          
          updated = [
            ...updated.slice(0, colIdx),
            flippedColumn,
            ...updated.slice(colIdx + 1),
          ];
          
          setCompleted(c => {
            const newCompleted = c + 1;
            if (isGameWon(newCompleted)) {
              setGameWon(true);
              setTimeout(() => sounds.win(), 500);
            }
            return newCompleted;
          });
          
          setTimeout(() => setAnimatingCards(new Set()), 500);
          break;
        }
      }
    }
    
    return updated;
  }, []);

  // Handle card click
  const handleCardClick = useCallback((columnIndex: number, cardIndex: number) => {
    if (gameWon) return;
    
    if (!selectedCard) {
      // Select cards if they form a valid sequence
      const column = tableau[columnIndex];
      const movableCount = getMovableCardCount(column, cardIndex);
      
      if (movableCount > 0 && cardIndex + movableCount === column.length) {
        setSelectedCard({ columnIndex, cardIndex });
        sounds.cardSelect();
      } else {
        sounds.invalidMove();
      }
    } else {
      if (selectedCard.columnIndex === columnIndex) {
        // Clicking on same column - deselect
        setSelectedCard(null);
        sounds.cardSelect();
      } else {
        // Try to move cards
        const sourceColumn = tableau[selectedCard.columnIndex];
        const cardsToMove = sourceColumn.slice(selectedCard.cardIndex);
        const targetColumn = tableau[columnIndex];
        
        if (canMoveCards(cardsToMove) && canPlaceCards(targetColumn, cardsToMove)) {
          // Perform the move
          const newSourceColumn = flipTopCard(sourceColumn.slice(0, selectedCard.cardIndex));
          const newTargetColumn = [...targetColumn, ...cardsToMove];
          
          // Play place sound
          sounds.cardPlace();
          
          // Play flip sound if a card was flipped
          if (newSourceColumn.length > 0 && 
              sourceColumn.slice(0, selectedCard.cardIndex).length > 0 &&
              !sourceColumn[selectedCard.cardIndex - 1]?.faceUp) {
            setTimeout(() => sounds.cardFlip(), 150);
          }
          
          let newTableau = [...tableau];
          newTableau[selectedCard.columnIndex] = newSourceColumn;
          newTableau[columnIndex] = newTargetColumn;
          
          // Check for completed runs
          newTableau = checkAndRemoveRuns(newTableau);
          
          setTableau(newTableau);
          setMoves(m => m + 1);
        } else {
          sounds.invalidMove();
        }
        
        setSelectedCard(null);
      }
    }
  }, [selectedCard, tableau, gameWon, checkAndRemoveRuns]);

  // Handle clicking on empty column
  const handleEmptyColumnClick = useCallback((columnIndex: number) => {
    if (gameWon || !selectedCard) return;
    
    const sourceColumn = tableau[selectedCard.columnIndex];
    const cardsToMove = sourceColumn.slice(selectedCard.cardIndex);
    
    if (canMoveCards(cardsToMove)) {
      const newSourceColumn = flipTopCard(sourceColumn.slice(0, selectedCard.cardIndex));
      const newTargetColumn = [...cardsToMove];
      
      // Play place sound
      sounds.cardPlace();
      
      // Play flip sound if a card was flipped
      if (newSourceColumn.length > 0 && 
          sourceColumn.slice(0, selectedCard.cardIndex).length > 0 &&
          !sourceColumn[selectedCard.cardIndex - 1]?.faceUp) {
        setTimeout(() => sounds.cardFlip(), 150);
      }
      
      let newTableau = [...tableau];
      newTableau[selectedCard.columnIndex] = newSourceColumn;
      newTableau[columnIndex] = newTargetColumn;
      
      newTableau = checkAndRemoveRuns(newTableau);
      
      setTableau(newTableau);
      setMoves(m => m + 1);
    }
    
    setSelectedCard(null);
  }, [selectedCard, tableau, gameWon, checkAndRemoveRuns]);

  // Handle deal from stock
  const handleDeal = useCallback(() => {
    if (gameWon) return;
    
    if (!canDealFromStock(tableau)) {
      // Show error - all columns must have cards
      sounds.invalidMove();
      return;
    }
    
    if (stock.length < 10) return;
    
    // Play deal sound
    sounds.deal();
    
    const { tableau: newTableau, stock: newStock } = dealFromStock(tableau, stock);
    const checkedTableau = checkAndRemoveRuns(newTableau);
    
    setTableau(checkedTableau);
    setStock(newStock);
    setMoves(m => m + 1);
    setSelectedCard(null);
  }, [tableau, stock, gameWon, checkAndRemoveRuns]);

  // Toggle sound
  const toggleSound = useCallback(() => {
    setSoundEnabled(prev => !prev);
    sounds.buttonClick();
  }, []);

  // Deselect on escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSelectedCard(null);
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return {
    tableau,
    stock,
    completed,
    moves,
    time,
    difficulty,
    selectedCard,
    gameStarted,
    gameWon,
    animatingCards,
    soundEnabled,
    canDeal: canDealFromStock(tableau) && stock.length >= 10,
    remainingDeals: Math.floor(stock.length / 10),
    startNewGame,
    handleCardClick,
    handleEmptyColumnClick,
    handleDeal,
    setSelectedCard,
    toggleSound,
  };
}
