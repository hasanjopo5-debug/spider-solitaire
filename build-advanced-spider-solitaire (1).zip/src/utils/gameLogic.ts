import { Card, Suit, Rank, Difficulty } from '../types/game';

const SUITS: Suit[] = ['spades', 'hearts', 'diamonds', 'clubs'];

export function createDeck(difficulty: Difficulty): Card[] {
  const suits = SUITS.slice(0, difficulty);
  const decksNeeded = 8 / difficulty;
  const cards: Card[] = [];
  
  for (let d = 0; d < decksNeeded; d++) {
    for (const suit of suits) {
      for (let rank = 1; rank <= 13; rank++) {
        cards.push({
          id: `${suit}-${rank}-${d}-${Math.random().toString(36).substr(2, 9)}`,
          suit,
          rank: rank as Rank,
          faceUp: false,
        });
      }
    }
  }
  
  return cards;
}

export function shuffleDeck(cards: Card[]): Card[] {
  const shuffled = [...cards];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

export function initializeGame(difficulty: Difficulty): { tableau: Card[][]; stock: Card[] } {
  const deck = shuffleDeck(createDeck(difficulty));
  
  const tableau: Card[][] = [];
  let cardIndex = 0;
  
  // First 4 columns get 6 cards, last 6 columns get 5 cards
  for (let col = 0; col < 10; col++) {
    const numCards = col < 4 ? 6 : 5;
    const column: Card[] = [];
    
    for (let i = 0; i < numCards; i++) {
      const card = { ...deck[cardIndex] };
      // Only the last card in each column is face up
      card.faceUp = i === numCards - 1;
      column.push(card);
      cardIndex++;
    }
    
    tableau.push(column);
  }
  
  // Remaining 50 cards go to stock
  const stock = deck.slice(cardIndex);
  
  return { tableau, stock };
}

export function canMoveCards(cards: Card[]): boolean {
  // Check if all cards form a valid descending sequence of the same suit
  for (let i = 0; i < cards.length - 1; i++) {
    if (cards[i].rank !== cards[i + 1].rank + 1) return false;
    if (cards[i].suit !== cards[i + 1].suit) return false;
  }
  return true;
}

export function canPlaceCards(targetColumn: Card[], cards: Card[]): boolean {
  // Can always place on empty column
  if (targetColumn.length === 0) return true;
  
  const topCard = targetColumn[targetColumn.length - 1];
  const bottomCard = cards[0];
  
  // Must be descending by one rank (suit doesn't matter for placement)
  return topCard.rank === bottomCard.rank + 1;
}

export function checkForCompleteRun(column: Card[]): { hasRun: boolean; runStartIndex: number } {
  if (column.length < 13) return { hasRun: false, runStartIndex: -1 };
  
  // Check for K to A sequence of same suit
  for (let startIdx = column.length - 13; startIdx >= 0; startIdx--) {
    const potentialRun = column.slice(startIdx, startIdx + 13);
    
    // All cards must be face up
    if (!potentialRun.every(c => c.faceUp)) continue;
    
    // Check if it's a valid K to A sequence of same suit
    let isValid = true;
    const suit = potentialRun[0].suit;
    
    for (let i = 0; i < 13; i++) {
      if (potentialRun[i].rank !== 13 - i || potentialRun[i].suit !== suit) {
        isValid = false;
        break;
      }
    }
    
    if (isValid) {
      return { hasRun: true, runStartIndex: startIdx };
    }
  }
  
  return { hasRun: false, runStartIndex: -1 };
}

export function flipTopCard(column: Card[]): Card[] {
  if (column.length === 0) return column;
  
  const newColumn = [...column];
  const topCard = { ...newColumn[newColumn.length - 1] };
  
  if (!topCard.faceUp) {
    topCard.faceUp = true;
    newColumn[newColumn.length - 1] = topCard;
  }
  
  return newColumn;
}

export function canDealFromStock(tableau: Card[][]): boolean {
  // All columns must have at least one card to deal
  return tableau.every(col => col.length > 0);
}

export function dealFromStock(tableau: Card[][], stock: Card[]): { tableau: Card[][]; stock: Card[] } {
  if (stock.length < 10) return { tableau, stock };
  if (!canDealFromStock(tableau)) return { tableau, stock };
  
  const newTableau = tableau.map((col, index) => {
    const newCard = { ...stock[index], faceUp: true };
    return [...col, newCard];
  });
  
  const newStock = stock.slice(10);
  
  return { tableau: newTableau, stock: newStock };
}

export function getMovableCardCount(column: Card[], startIndex: number): number {
  const cards = column.slice(startIndex);
  if (cards.length === 0 || !cards[0].faceUp) return 0;
  
  let count = 1;
  for (let i = 1; i < cards.length; i++) {
    if (!cards[i].faceUp) break;
    if (cards[i - 1].rank !== cards[i].rank + 1) break;
    if (cards[i - 1].suit !== cards[i].suit) break;
    count++;
  }
  
  return count;
}

export function isGameWon(completed: number): boolean {
  return completed === 8;
}
