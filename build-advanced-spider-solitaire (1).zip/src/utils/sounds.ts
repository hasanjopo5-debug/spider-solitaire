// Sound effects using Web Audio API
let audioContext: AudioContext | null = null;
let isMuted = false;

function getAudioContext(): AudioContext {
  if (!audioContext) {
    audioContext = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
  }
  return audioContext;
}

function playTone(
  frequency: number,
  duration: number,
  type: OscillatorType = 'sine',
  volume: number = 0.3,
  delay: number = 0
): void {
  if (isMuted) return;
  
  try {
    const ctx = getAudioContext();
    
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);
    
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, ctx.currentTime + delay);
    
    gainNode.gain.setValueAtTime(0, ctx.currentTime + delay);
    gainNode.gain.linearRampToValueAtTime(volume, ctx.currentTime + delay + 0.01);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + delay + duration);
    
    oscillator.start(ctx.currentTime + delay);
    oscillator.stop(ctx.currentTime + delay + duration);
  } catch (e) {
    console.warn('Audio playback failed:', e);
  }
}

function playNoise(duration: number, volume: number = 0.1, delay: number = 0): void {
  if (isMuted) return;
  
  try {
    const ctx = getAudioContext();
    
    const bufferSize = ctx.sampleRate * duration;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * 0.5;
    }
    
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;
    
    const gainNode = ctx.createGain();
    const filter = ctx.createBiquadFilter();
    
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(1000, ctx.currentTime + delay);
    
    noise.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(ctx.destination);
    
    gainNode.gain.setValueAtTime(volume, ctx.currentTime + delay);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + delay + duration);
    
    noise.start(ctx.currentTime + delay);
    noise.stop(ctx.currentTime + delay + duration);
  } catch (e) {
    console.warn('Audio playback failed:', e);
  }
}

export const sounds = {
  // Card select sound - short click
  cardSelect: () => {
    playTone(800, 0.08, 'square', 0.15);
  },
  
  // Card place sound - soft thud
  cardPlace: () => {
    playTone(150, 0.15, 'sine', 0.25);
    playNoise(0.08, 0.1);
  },
  
  // Card flip sound
  cardFlip: () => {
    playNoise(0.06, 0.15);
    playTone(400, 0.05, 'sine', 0.1, 0.02);
  },
  
  // Deal cards sound - multiple card sounds
  deal: () => {
    for (let i = 0; i < 10; i++) {
      setTimeout(() => {
        playNoise(0.05, 0.08);
        playTone(300 + Math.random() * 100, 0.04, 'sine', 0.08);
      }, i * 40);
    }
  },
  
  // Complete run sound - ascending arpeggio
  completeRun: () => {
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    notes.forEach((freq, i) => {
      playTone(freq, 0.3, 'sine', 0.2, i * 0.1);
    });
    // Add a shimmer
    setTimeout(() => {
      playTone(1318.51, 0.5, 'sine', 0.15); // E6
    }, 400);
  },
  
  // Invalid move sound - low buzz
  invalidMove: () => {
    playTone(150, 0.15, 'sawtooth', 0.2);
    playTone(140, 0.15, 'sawtooth', 0.2, 0.05);
  },
  
  // Win sound - victory fanfare
  win: () => {
    const melody = [
      { freq: 523.25, delay: 0 },     // C5
      { freq: 659.25, delay: 0.15 },  // E5
      { freq: 783.99, delay: 0.3 },   // G5
      { freq: 1046.50, delay: 0.45 }, // C6
      { freq: 783.99, delay: 0.6 },   // G5
      { freq: 1046.50, delay: 0.75 }, // C6
    ];
    
    melody.forEach(({ freq, delay }) => {
      playTone(freq, 0.4, 'sine', 0.25, delay);
      playTone(freq * 1.5, 0.4, 'sine', 0.1, delay); // Add harmony
    });
  },
  
  // New game sound
  newGame: () => {
    playTone(440, 0.15, 'sine', 0.2);
    playTone(554.37, 0.15, 'sine', 0.2, 0.1);
    playTone(659.25, 0.2, 'sine', 0.2, 0.2);
  },
  
  // Button click
  buttonClick: () => {
    playTone(600, 0.06, 'square', 0.1);
  },
  
  // Toggle mute
  setMuted: (muted: boolean) => {
    isMuted = muted;
  },
  
  getMuted: () => isMuted,
  
  // Initialize audio context on user interaction
  init: () => {
    try {
      const ctx = getAudioContext();
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
    } catch (e) {
      console.warn('Audio initialization failed:', e);
    }
  },
};
