import { Difficulty } from '../types/game';

interface WinModalProps {
  moves: number;
  time: number;
  difficulty: Difficulty;
  onNewGame: () => void;
}

const DIFFICULTY_NAMES: Record<Difficulty, string> = {
  1: 'Easy',
  2: 'Medium',
  4: 'Hard',
};

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export function WinModal({ moves, time, difficulty, onNewGame }: WinModalProps) {
  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 animate-[fadeIn_0.3s_ease-out]">
      <div className="bg-gradient-to-br from-green-800 to-green-900 rounded-2xl p-8 shadow-2xl max-w-md mx-4 animate-[scaleIn_0.3s_ease-out]">
        <div className="text-center">
          <div className="text-6xl mb-4 animate-bounce">🎉</div>
          <h2 className="text-3xl font-bold text-white mb-2">Congratulations!</h2>
          <p className="text-green-200 mb-6">You've completed Spider Solitaire!</p>
          
          <div className="bg-green-950/50 rounded-xl p-4 mb-6 space-y-2">
            <div className="flex justify-between text-green-200">
              <span>Difficulty:</span>
              <span className="font-bold text-white">{DIFFICULTY_NAMES[difficulty]}</span>
            </div>
            <div className="flex justify-between text-green-200">
              <span>Moves:</span>
              <span className="font-bold text-white">{moves}</span>
            </div>
            <div className="flex justify-between text-green-200">
              <span>Time:</span>
              <span className="font-bold text-white">{formatTime(time)}</span>
            </div>
          </div>
          
          <button
            onClick={onNewGame}
            className="w-full px-6 py-3 bg-gradient-to-r from-yellow-500 to-orange-500 text-white font-bold rounded-lg shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all duration-200"
          >
            Play Again
          </button>
        </div>
      </div>
    </div>
  );
}
