import { Card as CardType } from '../types/game';
import { Card } from './Card';
import { cn } from '../utils/cn';

interface ColumnProps {
  cards: CardType[];
  columnIndex: number;
  selectedCard: { columnIndex: number; cardIndex: number } | null;
  onCardClick: (columnIndex: number, cardIndex: number) => void;
  onColumnClick: () => void;
  animatingCards?: Set<string>;
}

export function Column({
  cards,
  columnIndex,
  selectedCard,
  onCardClick,
  onColumnClick,
  animatingCards,
}: ColumnProps) {
  const isThisColumnSelected = selectedCard?.columnIndex === columnIndex;

  return (
    <div
      className={cn(
        'relative min-h-[180px] md:min-h-[220px] w-16 md:w-20 rounded-lg',
        cards.length === 0 && 'bg-green-800/30 border-2 border-dashed border-green-600/50'
      )}
      onClick={() => cards.length === 0 && onColumnClick()}
    >
      {cards.map((card, cardIndex) => {
        const isSelected = isThisColumnSelected && selectedCard.cardIndex === cardIndex;
        const isPartOfSelection =
          isThisColumnSelected && selectedCard.cardIndex < cardIndex;
        const isAnimating = animatingCards?.has(card.id);

        return (
          <div
            key={card.id}
            className={cn(
              'absolute left-0 transition-all duration-300 ease-out',
              isAnimating && 'animate-pulse'
            )}
            style={{
              top: `${cardIndex * (card.faceUp ? 28 : 12)}px`,
              zIndex: cardIndex,
            }}
          >
            <Card
              card={card}
              onClick={() => card.faceUp && onCardClick(columnIndex, cardIndex)}
              isSelected={isSelected}
              isPartOfSelection={isPartOfSelection}
            />
          </div>
        );
      })}
    </div>
  );
}
