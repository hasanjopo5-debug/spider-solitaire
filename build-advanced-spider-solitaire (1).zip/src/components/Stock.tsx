import { cn } from '../utils/cn';

interface StockProps {
  remainingDeals: number;
  canDeal: boolean;
  onDeal: () => void;
}

export function Stock({ remainingDeals, canDeal, onDeal }: StockProps) {
  const piles = Math.ceil(remainingDeals);

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative w-20 h-28">
        {Array.from({ length: Math.min(piles, 5) }).map((_, index) => (
          <div
            key={index}
            onClick={canDeal && index === Math.min(piles, 5) - 1 ? onDeal : undefined}
            className={cn(
              'absolute w-16 h-22 md:w-20 md:h-28 rounded-lg',
              'bg-gradient-to-br from-blue-700 via-blue-800 to-blue-900',
              'border-2 border-blue-600',
              'flex items-center justify-center',
              'shadow-md',
              canDeal && index === Math.min(piles, 5) - 1 && 'cursor-pointer hover:shadow-lg hover:-translate-y-1 transition-all duration-200'
            )}
            style={{
              left: `${index * 2}px`,
              bottom: `${index * 2}px`,
              zIndex: index,
            }}
          >
            <div className="w-12 h-16 md:w-14 md:h-20 rounded border-2 border-blue-500/50 bg-blue-800/50 flex items-center justify-center">
              <span className="text-2xl md:text-3xl text-blue-400">🕷️</span>
            </div>
          </div>
        ))}
        {piles === 0 && (
          <div className="w-16 h-22 md:w-20 md:h-28 rounded-lg border-2 border-dashed border-green-600/50 bg-green-800/20" />
        )}
      </div>
      <span className="text-sm text-green-200 font-medium">
        {remainingDeals} deal{remainingDeals !== 1 ? 's' : ''} left
      </span>
    </div>
  );
}
