interface GameStatsProps {
  moves: number;
  time: number;
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export function GameStats({ moves, time }: GameStatsProps) {
  return (
    <div className="flex gap-6 text-green-200">
      <div className="flex items-center gap-2">
        <span className="text-xl">🎯</span>
        <div>
          <div className="text-xs opacity-70">Moves</div>
          <div className="text-lg font-bold">{moves}</div>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-xl">⏱️</span>
        <div>
          <div className="text-xs opacity-70">Time</div>
          <div className="text-lg font-bold">{formatTime(time)}</div>
        </div>
      </div>
    </div>
  );
}
