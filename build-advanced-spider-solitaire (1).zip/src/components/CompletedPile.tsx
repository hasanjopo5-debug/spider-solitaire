import { cn } from '../utils/cn';

interface CompletedPileProps {
  count: number;
}

export function CompletedPile({ count }: CompletedPileProps) {
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative w-20 h-28">
        {count === 0 ? (
          <div className="w-16 h-22 md:w-20 md:h-28 rounded-lg border-2 border-dashed border-green-600/50 bg-green-800/20 flex items-center justify-center">
            <span className="text-green-600/50 text-2xl">✓</span>
          </div>
        ) : (
          Array.from({ length: Math.min(count, 8) }).map((_, index) => (
            <div
              key={index}
              className={cn(
                'absolute w-16 h-22 md:w-20 md:h-28 rounded-lg shadow-md',
                'bg-white border-2 border-gray-200',
                'animate-[slideIn_0.3s_ease-out]'
              )}
              style={{
                left: `${index * 3}px`,
                bottom: `${index * 2}px`,
                zIndex: index,
              }}
            >
              <div className="relative w-full h-full p-1">
                <div className="absolute top-1 left-1 flex flex-col items-center leading-none text-gray-900">
                  <span className="text-xs md:text-sm font-bold">A</span>
                  <span className="text-xs md:text-sm">♠</span>
                </div>
                <div className="absolute inset-0 flex items-center justify-center text-gray-900">
                  <span className="text-2xl md:text-4xl">♠</span>
                </div>
                <div className="absolute bottom-1 right-1 flex flex-col items-center leading-none rotate-180 text-gray-900">
                  <span className="text-xs md:text-sm font-bold">A</span>
                  <span className="text-xs md:text-sm">♠</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
      <span className="text-sm text-green-200 font-medium">
        {count}/8 completed
      </span>
    </div>
  );
}
