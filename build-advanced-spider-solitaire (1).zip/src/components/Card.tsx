import { Card as CardType, SUIT_SYMBOLS, SUIT_COLORS, RANK_DISPLAY } from '../types/game';
import { cn } from '../utils/cn';

interface CardProps {
  card: CardType;
  onClick?: () => void;
  isSelected?: boolean;
  isPartOfSelection?: boolean;
  style?: React.CSSProperties;
}

export function Card({ card, onClick, isSelected, isPartOfSelection, style }: CardProps) {
  const symbol = SUIT_SYMBOLS[card.suit];
  const color = SUIT_COLORS[card.suit];
  const rankDisplay = RANK_DISPLAY[card.rank];

  if (!card.faceUp) {
    return (
      <div
        style={style}
        className={cn(
          'w-16 h-22 md:w-20 md:h-28 rounded-lg shadow-md cursor-pointer',
          'bg-gradient-to-br from-blue-700 via-blue-800 to-blue-900',
          'border-2 border-blue-600',
          'flex items-center justify-center',
          'transition-all duration-200 ease-out',
          'hover:shadow-lg hover:-translate-y-0.5'
        )}
      >
        <div className="w-12 h-16 md:w-14 md:h-20 rounded border-2 border-blue-500/50 bg-blue-800/50 flex items-center justify-center">
          <span className="text-2xl md:text-3xl text-blue-400">🕷️</span>
        </div>
      </div>
    );
  }

  return (
    <div
      onClick={onClick}
      style={style}
      className={cn(
        'w-16 h-22 md:w-20 md:h-28 rounded-lg shadow-md cursor-pointer select-none',
        'bg-white border-2',
        'transition-all duration-200 ease-out',
        isSelected || isPartOfSelection
          ? 'border-yellow-400 ring-2 ring-yellow-400 shadow-yellow-200 -translate-y-1 z-10'
          : 'border-gray-200 hover:shadow-lg hover:-translate-y-0.5',
      )}
    >
      <div className="relative w-full h-full p-1">
        {/* Top left corner */}
        <div className={cn('absolute top-1 left-1 flex flex-col items-center leading-none', color)}>
          <span className="text-xs md:text-sm font-bold">{rankDisplay}</span>
          <span className="text-xs md:text-sm">{symbol}</span>
        </div>
        
        {/* Center symbol */}
        <div className={cn('absolute inset-0 flex items-center justify-center', color)}>
          <span className="text-2xl md:text-4xl">{symbol}</span>
        </div>
        
        {/* Bottom right corner (rotated) */}
        <div className={cn('absolute bottom-1 right-1 flex flex-col items-center leading-none rotate-180', color)}>
          <span className="text-xs md:text-sm font-bold">{rankDisplay}</span>
          <span className="text-xs md:text-sm">{symbol}</span>
        </div>
      </div>
    </div>
  );
}
