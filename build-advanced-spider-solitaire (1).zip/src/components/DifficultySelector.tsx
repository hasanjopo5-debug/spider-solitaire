import { Difficulty } from '../types/game';
import { cn } from '../utils/cn';

interface DifficultySelectorProps {
  currentDifficulty: Difficulty;
  onSelect: (difficulty: Difficulty) => void;
}

const DIFFICULTY_INFO: Record<Difficulty, { name: string; description: string; color: string }> = {
  1: { name: 'Easy', description: '1 Suit (Spades)', color: 'from-green-500 to-green-600' },
  2: { name: 'Medium', description: '2 Suits (Spades & Hearts)', color: 'from-yellow-500 to-orange-500' },
  4: { name: 'Hard', description: '4 Suits (All)', color: 'from-red-500 to-red-600' },
};

export function DifficultySelector({ currentDifficulty, onSelect }: DifficultySelectorProps) {
  return (
    <div className="flex flex-wrap justify-center gap-2 md:gap-4">
      {([1, 2, 4] as Difficulty[]).map((difficulty) => {
        const info = DIFFICULTY_INFO[difficulty];
        const isSelected = currentDifficulty === difficulty;

        return (
          <button
            key={difficulty}
            onClick={() => onSelect(difficulty)}
            className={cn(
              'px-4 py-2 md:px-6 md:py-3 rounded-lg font-medium transition-all duration-200',
              'shadow-md hover:shadow-lg hover:-translate-y-0.5',
              isSelected
                ? `bg-gradient-to-r ${info.color} text-white ring-2 ring-white/50`
                : 'bg-green-800/50 text-green-200 hover:bg-green-700/50'
            )}
          >
            <div className="text-sm md:text-base font-bold">{info.name}</div>
            <div className="text-xs opacity-80">{info.description}</div>
          </button>
        );
      })}
    </div>
  );
}
